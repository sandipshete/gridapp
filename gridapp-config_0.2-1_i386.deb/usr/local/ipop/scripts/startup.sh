#!/bin/bash
dir="/usr/local/ipop"
VMM=`$dir/scripts/utils.sh vmm`


$dir/scripts/monitor.sh &> /var/log/monitor.log &


clear
